import { lazyLoad } from 'core';

export const Dashboard = lazyLoad(() => import('../features/Dashboard'));

export default Dashboard;
