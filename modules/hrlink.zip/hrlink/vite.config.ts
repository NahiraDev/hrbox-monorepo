import { type ConfigEnv, defineConfig } from 'vite';

import { baseConfig } from '../../configs/vite.config.base';

export default defineConfig((env: ConfigEnv) => {
  const config = baseConfig(env);

  return {
    base: '/hrlink',
    ...config,
  };
});
